<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'LoginController';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;


$route['home'] = "CityController/home";
$route['signup'] = "RegisterController/index";
$route['logout'] = "LogoutController/index";

$route['hyd/golkonda'] = "CityController/golkonda";
$route['hyd/hyderabad']="CityController/hyderabad";
$route['hyd/charminar']="CityController/charminar";
$route['hyd/salarjung']="CityController/salarjung";


$route['kerla/kerala']="CityController/kerala";
$route['kerla/alleppey']="CityController/alleppey";
$route['kerla/cochin']="CityController/cochin";
$route['kerla/wayanad']="CityController/wayanad";


$route['kol/kolkata']="CityController/kolkata";
$route['kol/howrahbridge']="CityController/howrahbridge";
$route['kol/indianmuseum']="CityController/indianmuseum";
$route['kol/victoria']="CityController/victoria";


$route['mumb/mumbai']="CityController/mumbai";
$route['mumb/elephantcaves']="CityController/elephantcaves";
$route['mumb/gateway']="CityController/gateway";
$route['mumb/marina']="CityController/marina";


$route['del/delhi']="CityController/delhi";
$route['del/delhizoo']="CityController/delhizoo";
$route['del/redfort']="CityController/redfort";
$route['del/tajmahal']="CityController/tajmahal";




$route['hyd/booking']="CityController/booking";
$route['del/booking']="CityController/booking";
$route['kerla/booking']="CityController/booking";
$route['kol/booking']="CityController/booking";
$route['mumb/booking']="CityController/booking";
$route['about']="CityController/about";

$route['contact']="CityController/contact";
$route['hyd/checkout']="CityController/checkout";
$route['del/checkout']="CityController/checkout";
$route['kerla/checkout']="CityController/checkout";
$route['mumb/checkout']="CityController/checkout";
$route['kol/checkout']="CityController/checkout";
$route['services']="CityController/services";
