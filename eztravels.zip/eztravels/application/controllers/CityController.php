<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CityController extends CI_Controller {


	public function index()
	{
		$this->load->view('welcome_message');
	}

public function home()
{
	$this->load->view('home');
}

  public function golkonda()
  {
    $this->load->view('hyd/golkonda');
  }
	public function hyderabad()
	{
		$this->load->view('hyd/hyderabad');
	}
  public function charminar()
	  {
	    $this->load->view('hyd/charminar');
	  }
		public function salarjung()
	  {
	    $this->load->view('hyd/salarjung');
	  }






	public function kerala()
  {
    $this->load->view('kerla/kerala');
  }
	public function alleppey()
  {
    $this->load->view('kerla/alleppey');
  }
	public function cochin()
	{
		$this->load->view('kerla/cochin');
	}
	public function wayanad()
	{
		$this->load->view('kerla/wayanad');
	}






	public function mumbai()
  {
    $this->load->view('mumb/mumbai');
  }
	public function elephantcaves()
  {
    $this->load->view('mumb/elephantcaves');
  }
	public function marina()
	{
		$this->load->view('mumb/marina');
	}
	public function gateway()
	{
		$this->load->view('mumb/gateway');
	}






public function kolkata()
  {
    $this->load->view('kol/kolkata');
  }
	public function howrahbridge()
	{
	  $this->load->view('kol/howrahbridge');
	}
	public function indianmuseum()
	{
	  $this->load->view('kol/indianmuseum');
	}
	public function victoria()
  {
		$this->load->view('kol/victoria');
  }


 public function delhi()
  {
    $this->load->view('del/delhi');
  }
	public function delhizoo()
   {
     $this->load->view('del/delhizoo');
   }
	 public function redfort()
	  {
	 	 $this->load->view('del/redfort');
	  }
		public function tajmahal()
		 {
			 $this->load->view('del/tajmahal');
		 }




public function booking()
	{
		$this->load->view('booking');
	}
	public function about()
		{
			$this->load->view('about');
		}
		public function contact()
			{
				$this->load->view('contact');
			}
	public function checkout()
	{
		$this->load->view('checkout');
	}
	public function services()
	{
		$this->load->view('services');
	}



}


?>
