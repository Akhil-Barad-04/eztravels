<?php $this->load->view("layout/header") ?>
<head>
  <link rel="stylesheet" href="<?php echo base_url("assets/css/bootstrap.css") ?>">
  <style>
      body{

      }
      .fleft{
        position: absolute;
        right:20px;
        float:right;
        height:500px;
        width:50%;
        margin-top:0px;
        border-radius: 10px;
        margin-right:20px;
      }
      #fright{
        color:white;
         margin-left:50px;
         width:900px;
         float:left;

      }
      .img11{
        width:500px;
        height:400px;
      }
      #p1{
          color:white;
          position: absolute;
          bottom:220px;
          left:350px;
          font-size:30px;
      }
      #p2{
          color:white;
          position: absolute;
          bottom:180px;
          left:450px;
          font-size:20px;
      }
      #p3{

          color:white;
          position: absolute;
          bottom:130px;
          left:465px;
      }
      #hh{
        position: relative;
        margin:20px 0 20px 0;
        color:white;
        left:45%;
      }

  </style>
</head>
<body style="background-color:black; overflow:hidden;">
  <h2 id="hh">Golkonda Fort</h2>

    <p id="fright" >

         Golconda was originally known as Mankal. Golconda Fort was first built by the Kakatiyas as part of their western
         defenses along the lines of the Kondapalli Fort. The city and the fortress were built on a granite hill that is 120
         meters (390 ft) high, surrounded by massive battlements. The fort was rebuilt and strengthened by Rani Rudrama Devi
         and her successor Prataparudra.[2][3] Later, the fort came under the control of the Kamma Nayakas, who defeated the
          Tughlaqi army occupying Warangal. It was ceded by Kamma king Musunuri Kapaya Nayaka to the Bahmani Sultanate as part of a treaty in 1364.

        Under the Bahmani Sultanate, Golconda slowly rose to prominence. Sultan Quli Qutb-ul-Mulk (r. 1487–1543), sent by the Bahmanids as a governor at Golconda, established the city as the seat of his government around 1501. Bahmani rule gradually weakened during this period, and Sultan Quli formally became independent in 1538, establishing the Qutb Shahi dynasty based in Golconda.[7][8] Over a period of 62 years, the mud fort was expanded by the first three Qutb Shahi sultans into the present structure, a massive fortification of granite extending around 5 km (3.1 mi) in circumference. It remained the capital of the Qutb Shahi dynasty until 1590 when the capital was shifted to Hyderabad. The Qutb Shahis expanded the fort, whose 7 km (4.3 mi) outer wall enclosed the city.


    </p>
    <img  class="img11 fleft" src="/eztravels/images/golkonda.jpg">

    <p id="p1">Timings:-9:00AM-8:00PM</p>
    <p id="p2">Entry Fee:100/-</p>
    <a type="button" href="booking" class="btn btn-primary" id="p3">Book Now</a>
<footer style="position:absolute; bottom:0px; width:100%;">
  <?php $this->load->view("layout/footer") ?>
</footer>
</body>
