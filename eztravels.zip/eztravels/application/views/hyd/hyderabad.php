<?php $this->load->view("layout/header") ?>
<style>

#h1{
  color: black;
  text-align: center;
  margin-bottom: 20px;
  margin-top: 20px;
}
.imgp{
  color:black;
  font-size:20px;
  text-align: center;
}
.imgh{
  width:500px;
  height:400px;
  display: block;
 margin-left: auto;
 margin-right: auto;
  border-radius: 10px;
}
</style>

<h1 id="h1"> HYDERABAD </h1>
<body style="background-color:white;">
  <a href="golkonda" ><img class="imgh" src="/eztravels/images/golkonda.jpg"></a>
  <p class="imgp">Golkonda</p>
  <a href="charminar" ><img class="imgh" src="/eztravels/images/charminar.jpg"></a>
  <p class="imgp">Charminar</p>
  <a href="salarjung" ><img class="imgh" src="/eztravels/images/salar.jpg"></a>
  <p class="imgp">Salar jung Museum</p>


</body>
<?php $this->load->view("layout/footer") ?>
