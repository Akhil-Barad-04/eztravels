<?php $this->load->view("layout/header") ?>

<style>
body{
  background-image: url("alleppey.jpg");
}
#h1{
  color: black;
  text-align: center;
  margin-bottom: 20px;
  margin-top: 20px;
}
.imgp{
  color:black;
  font-size:20px;
  text-align: center;
}
.imgh{
  width:500px;
  height:400px;
  display: block;
 margin-left: auto;
 margin-right: auto;
  border-radius: 10px;
}
</style>

<h1 id="h1"> KERALA </h1>
<body style="background-color:white;" >
  <a href="alleppey" ><img class="imgh" src="/eztravels/images/alleppey.jpg"></a>
  <p class="imgp">Alleppey</p>
  <a href="wayanad" ><img class="imgh" src="/eztravels/images/wayanad.jpg"></a>
  <p class="imgp">Wayanad</p>
  <a href="cochin" ><img class="imgh" src="/eztravels/images/cochin.jpg"></a>
  <p class="imgp">Cochin</p>


</body>



<?php $this->load->view("layout/footer") ?>
