
<?php $this->load->view("layout/header") ?>
<html>

<style>


#h11{
  color: white;
  text-align: center;
  margin-bottom: 20px;
  margin-top: 20px;
}
.imgp{
  color:white;
  font-size:20px;
text-align: center;
}
.imgt{
  display: block;
 margin-left: auto;
 margin-right: auto;
  width:500px;
  height:400px;


  border-radius: 10px;
}

</style>


<h1 id="h11">List of Places</h1>
<body style="background-image:url('bg.jpg'); background-repeat:no-repeat; background-size:cover;">
    <a href="hyd/hyderabad" ><img class="imgt" src="/eztravels/images/hyderabad.jpg"></a>
    <p class="imgp">Hyderabad</p>
    <a href="del/delhi"><img class="imgt" src="/eztravels/images/delhi.jpg"></a>
    <p class="imgp">Delhi</p>
    <a href="kerla/kerala"><img class="imgt" src="/eztravels/images/kerala.jpg"></a>
    <p class="imgp">Kerala</p>
    <a href="mumb/mumbai"><img class="imgt" src="/eztravels/images/mumbai.jpg"></a>
    <p class="imgp">Mumbai</p>
    <a href="kol/kolkata"><img class="imgt" src="/eztravels/images/kolkata.jpg"></a>
    <p class="imgp">Kolkata</p>



</body>
</html>
<div>
<?php $this->load->view("layout/footer") ?>
</div>
