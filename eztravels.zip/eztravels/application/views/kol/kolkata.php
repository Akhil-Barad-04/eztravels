<?php $this->load->view("layout/header") ?>


<style>
body{
  background-image: url("alleppey.jpg");
}
#h1{
  color: black;
  text-align: center;
  margin-bottom: 20px;
  margin-top: 20px;
}
.imgp{
  color:black;
  font-size:20px;
  text-align: center;
}
.imgh{
  width:500px;
  height:400px;
  margin-left:500px;
  border-radius: 10px;
}
</style>

<h1 id="h1"> KOLKATA </h1>
<body style="background-color:white;">
  <a href="victoria" ><img class="imgh" src="/eztravels/images/victoria.jpg"></a>
  <p class="imgp">Victoria Memorial</p>
  <a href="howrahbridge" ><img class="imgh" src="/eztravels/images/howrah.jpg"></a>
  <p class="imgp">Howrah Bridge</p>
  <a href="indianmuseum" ><img class="imgh" src="/eztravels/images/indian.jpg"></a>
  <p class="imgp">Indian Museum</p>


</body>







<?php $this->load->view("layout/footer") ?>
