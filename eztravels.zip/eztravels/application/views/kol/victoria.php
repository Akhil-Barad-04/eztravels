
<?php $this->load->view("layout/header") ?>
<head>
  <link rel="stylesheet" href="<?php echo base_url("assets/css/bootstrap.css") ?>">
  <style>
      body{

      }
      .fleft{
        position: absolute;
        right:20px;
        float:right;
        height:500px;
        width:50%;
        margin-top:0px;
        border-radius: 10px;
        margin-right:20px;
      }
      #fright{
        color:white;
         margin-left:50px;
         width:900px;
         float:left;

      }
      .img11{
        width:500px;
        height:400px;
      }
      #p1{
          color:white;
          position: absolute;
          bottom:250px;
          left:350px;
          font-size:30px;
      }
      #p2{
          color:white;
          position: absolute;
          bottom:200px;
          left:450px;
          font-size:20px;
      }
      #p3{

          color:white;
          position: absolute;
          bottom:150px;
          left:465px;
      }
      #hh{
        position: relative;
        margin:20px 0 20px 0;
        color:white;
        left:45%;
      }

  </style>
</head>
<body style="background-color:black; overflow:hidden;">
  <h2 id="hh">Victoria Memorial</h2>

    <p id="fright">

            The Victoria Memorial is a large marble building in Kolkata, West Bengal, India, which was built between 1906 and 1921. It is dedicated to the memory of Queen Victoria, then Empress of India, and is now a museum and tourist destination under the auspices of the Ministry of Culture.[2] The memorial lies on the Maidan (grounds) by the bank of the Hooghly River, near Jawaharlal Nehru Road (better known as Chowringhee Road).


    </p>
    <img class="img11 fleft" src="/eztravels/images/victoria.jpg">

    <p id="p1">Timings:-9:00AM-8:00PM</p>
    <p id="p2">Entry Fee:100/-</p>
    <a type="button" href="booking" class="btn btn-primary" id="p3">Book Now</a>
<footer style="position:absolute; bottom:0px; width:100%;">
  <?php $this->load->view("layout/footer") ?>
</footer>
</body>
