
<head>
  <link rel="stylesheet" href="<?php echo base_url("assets/css/bootstrap.css") ?>">
  <script src="<?php echo base_url("assets/js/jquery.js") ?>" charset="utf-8"></script>
  <script src="<?php echo base_url("assets/js/bootstrap.bundle.min.js") ?>" charset="utf-8"></script>
  <script src="<?php echo base_url("assets/js/bootstrap.min.js") ?>" charset="utf-8"></script>
  <script src="<?php echo base_url("assets/js/extra.js") ?>" charset="utf-8"></script>


</head>
<style>

.foocol{
        border-right:none;
        height:100%;

    }
.foocol:last-child{
    border-right: none;
}

</style>


<footer class="container-fluid" style="height:100px;  width:100vw; margin-top:50px; background-color:#563d7c; position:relative; bottom:0px;">
  <div class="row  foocol" >
    <div class="col-sm foocol txt">
      <h2 style="color:black;">Ez Travels</h2>
      <p style="font-size:20px; color:black;">Nizamabad</p>
    </div>
    <div class="col-sm foocol txt">
      <pre style="font-size:25px;color:black;">
             Contact us:
      akhilbarad29966@gmail.com
      </pre>
    </div>
    <div class="col-sm foocol txt">
    <pre style="font-size:25px;color:black;">

              Akhil Barad
    </pre>
    </div>
  </div>
</footer>
