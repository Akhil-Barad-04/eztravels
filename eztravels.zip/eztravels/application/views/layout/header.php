<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Ez Travels</title>
    <link rel="stylesheet" href="<?php echo base_url("assets/css/bootstrap-grid.min.css") ?>">
    <link rel="stylesheet" href="<?php echo base_url("assets/css/bootstrap-reboot.min.css") ?>">
    <link rel="stylesheet" href="<?php echo base_url("assets/css/bootstrap.min.css") ?>">
    <link rel="stylesheet" href="<?php echo base_url("assets/css/custom.css") ?>">
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar" style="background-color:#563d7c;">
      <div class="container">
        <a class="navbar-brand" style="color:white;" href="<?php echo base_url(); ?>">Ez Travels</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link"style="color:white;" href="<?php echo base_url(); ?>">Home</a>
          </li>
          <li class="nav-item">
            <?php if (isset($_SESSION['username'])): ?>
              <a class="nav-link"style="color:white;" href="<?php echo base_url("about");?>">About</a>
              <?php else: ?>
              <a class="nav-link"style="color:white;" href="<?php echo base_url();?>">About</a>
            <?php endif; ?>

          </li>
          <li class="nav-item">
            <?php if (isset($_SESSION['username'])): ?>
              <a class="nav-link"style="color:white;" href="<?php echo base_url("services");?>">Services</a>
              <?php else: ?>
              <a class="nav-link"style="color:white;" href="<?php echo base_url();?>">Services</a>
            <?php endif; ?>


          </li>
          <li class="nav-item">
            <?php if (isset($_SESSION['username'])): ?>
              <a class="nav-link"style="color:white;" href="<?php echo base_url("logout");?>">logout</a>
              <?php else: ?>
              <a class="nav-link"style="color:white;" href="<?php echo base_url("signup");?>">Sign up</a>
            <?php endif; ?>
          </li>
        </ul>

      </div>
      </div>
    </nav>
