
<?php $this->load->view("layout/header") ?>
<head>
  <link rel="stylesheet" href="<?php echo base_url("assets/css/bootstrap.css") ?>">
  <style>
      body{
        background-image: linear-gradient(to right, red, blue);
        overflow:hidden;


      }
      .fleft{
        position: absolute;
        right:20px;
        float:right;
        height:500px;
        width:50%;
        margin-top:0px;
        border-radius: 10px;
        margin-right:20px;
      }
      #fright{
        color:white;
         margin-left:50px;
         width:900px;
         float:left;

      }
      .img11{
        width:500px;
        height:400px;
      }

      #hh{
        position: relative;
        margin:20px 0 20px 0;
        color:white;
        left:45%;
      }

  </style>
</head>
<body>
  <h2 id="hh">About Us</h2>

    <p id="fright">
        <i><b>EzTravels</b> is the world's leading bus ticket booking company.
        It operates in 6 countries (India, Malaysia, Singapore, Indonesia, Peru, and Colombia).
        <b>EzTravels</b> has sold over 180 million bus tickets worldwide through the <b>EzTravels </b>website and app.
        With over 17 million satisfied customers, <b>EzTravels</b> has set the bar quite high.

        Only for you we got rid of the long queues on jammed streets and bus stations for bus tickets, we got rid of agents cheating you with jacked up bus ticket prices, we are the pioneers who revolutionized the online bus booking in India. Booking a bus ticket from your couch or when you are on the move was made possible by us by just logging on to <b>Eztravels.com.</b>

          You could book bus tickets to anywhere in India from over 2500 bus operators covering over 100000 routes for Sleeper, AC, Semi luxury, Luxury, and coaches from Volvo, Scania, Ashok Leyland to Mercedes at click of a button and to make payment convenient we have multiple payment options like, Debit/Credit, Net Banking.

          <b>EzTravels</b> Customer Service representatives are available 24 X7 365 days a year, who are happy to help you book your bus ticket online or attend to any of your queries.

          So next time you think of bus, just <b>Ez Travels it...</b></i>
    </p>
      <img class="img11 fleft" src="/eztravels/images/about.jpg"">


<footer style="position:absolute; bottom:0px; width:100%;">
  <?php $this->load->view("layout/footer") ?>
</footer>
</body>
