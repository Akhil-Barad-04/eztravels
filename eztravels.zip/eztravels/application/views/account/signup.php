<?php $this->load->view("layout/header") ?>
<body style="background-image:url('ez2.jpg'); background-repeat:no-repeat; background-size:cover;">
<section>

  <div class="container">
    <?php if (isset($_SESSION['success'])): ?>
      <div class="alert alert-success">
        <?php echo $this->session->flashdata('success'); ?>
      </div>
    <?php endif; ?>
  </div>
  <div class="container">
    <?php if (isset($_SESSION['error'])): ?>
      <div class="alert alert-danger">
        <?php echo $this->session->flashdata('error'); ?>
      </div>
    <?php endif; ?>
  </div>

<div >

    <div  class="col-md-3 card p-5 center" style="background-image:url('ez7.jpg'); background-repeat:no-repeat; background-size:cover;">
      <hr>
      <h4 style="color:white;">Signup</h4>
      <form action="" method="post">
        <div class="form-group">
          <label for=""style="color:white;">Name</label>
          <input type="text" name="name" id="" class="form-control rounded-0" placeholder="Name" />
          <span class="text-danger"><?php echo form_error('name'); ?></span>
        </div>
        <div class="form-group">
          <label for=""style="color:white;">Password</label>
          <input type="password" name="password" id="" class="form-control rounded-0" placeholder="Password"  />
          <span class="text-danger"><?php echo form_error('password'); ?></span>
        </div>
        <div class="form-group">
          <label for=""style="color:white;">Confirm Password</label>
          <input type="password" name="confirm" id="" class="form-control rounded-0" placeholder="Confirm Password"  />
          <span class="text-danger"><?php echo form_error('confirm'); ?></span>
        </div>
        <div class="form-group">
          <label for=""style="color:white;">Email</label>
          <input type="text" name="email" id="" class="form-control rounded-0" placeholder="Email" />
          <span class="text-danger"><?php echo form_error('email'); ?></span>
        </div>
        <div class="form-group">
          <label for=""style="color:white;">Phone</label>
          <input type="text" name="phone" id="" class="form-control rounded-0" placeholder="Phone" />
          <span class="text-danger"><?php echo form_error('phone'); ?></span>
        </div>
        <div class="form-group">
          <button type="submit" class="btn btn-primary rounded-0" name="button">Post</button>
        </div>
      </form>

    </div>
  </div>
</section>
</body>
