
<body>
  <h2>Thank You for contacting us.</h2>
  <h2>Have a Good Day.</h2>
</body>
