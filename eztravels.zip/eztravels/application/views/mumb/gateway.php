
<?php $this->load->view("layout/header") ?>
<head>
  <link rel="stylesheet" href="<?php echo base_url("assets/css/bootstrap.css") ?>">
  <style>
      body{

      }
      .fleft{
        position: absolute;
        right:20px;
        float:right;
        height:500px;
        width:50%;
        margin-top:0px;
        border-radius: 10px;
        margin-right:20px;
      }
      #fright{
        color:white;
         margin-left:50px;
         width:900px;
         float:left;

      }
      .img11{
        width:500px;
        height:400px;
      }
      #p1{
          color:white;
          position: absolute;
          bottom:250px;
          left:350px;
          font-size:30px;
      }
      #p2{
          color:white;
          position: absolute;
          bottom:200px;
          left:450px;
          font-size:20px;
      }
      #p3{

          color:white;
          position: absolute;
          bottom:150px;
          left:465px;
      }
      #hh{
        position: relative;
        margin:20px 0 20px 0;
        color:white;
        left:45%;
      }

  </style>
</head>
<body style="background-color:black; overflow:hidden;">
  <h2 id="hh">Gate Way of India</h2>

    <p id="fright">
      The Gateway of India is an arch-monument built in the early twentieth century in the city of Mumbai, in the Indian state of Maharashtra. It was erected to commemorate the landing in December 1911 at Apollo Bunder, Mumbai (then Bombay) of King-Emperor George V and Queen-Empress Mary, the first British monarch to visit India. At the time of the royal visit, the gateway was not yet built, and a cardboard structure greeted the monarch. The foundation stone was laid in March 1913 for a monument built in the Indo-Saracenic style, incorporating elements of 16th-century Marathi architecture. The final design of the monument by architect George Wittet was sanctioned only in 1914, and construction was completed in 1924. The structure is a triumphal arch made of basalt, which is 26 metres (85 feet) high.
          </p>
    <img class="img11 fleft" src="/eztravels/images/gateway.jpg">

    <p id="p1">Timings:-9:00AM-8:00PM</p>
    <p id="p2">Entry Fee:100/-</p>
    <a type="button" href="booking" class="btn btn-primary" id="p3">Book Now</a>
<footer style="position:absolute; bottom:0px; width:100%;">
  <?php $this->load->view("layout/footer") ?>
</footer>
</body>
