
<?php $this->load->view("layout/header") ?>
<head>
  <link rel="stylesheet" href="<?php echo base_url("assets/css/bootstrap.css") ?>">
  <style>
      body{

      }
      .fleft{
        position: absolute;
        right:20px;
        float:right;
        height:500px;
        width:50%;
        margin-top:0px;
        border-radius: 10px;
        margin-right:20px;
      }
      #fright{
        color:white;
         margin-left:50px;
         width:900px;
         float:left;

      }
      .img11{
        width:500px;
        height:400px;
      }
      #p1{
          color:white;
          position: absolute;
          bottom:250px;
          left:350px;
          font-size:30px;
      }
      #p2{
          color:white;
          position: absolute;
          bottom:200px;
          left:450px;
          font-size:20px;
      }
      #p3{

          color:white;
          position: absolute;
          bottom:150px;
          left:465px;
      }
      #hh{
        position: relative;
        margin:20px 0 20px 0;
        color:white;
        left:45%;
      }

  </style>
</head>
<body style="background-color:black; overflow:hidden;">
  <h2 id="hh">Elephant Caves</h2>

    <p id="fright">
      Elephanta Caves are a UNESCO World Heritage Site and a collection of cave temples predominantly dedicated to the Hindu god Shiva.[1][2][3] They are on Elephanta Island, or Gharapuri (literally "the city of caves"), in Mumbai Harbour, 10 kilometres (6.2 mi) east of Mumbai in the Indian state of Mahārāshtra. The island, about 2 kilometres (1.2 mi) west of the Jawaharlal Nehru Port, consists of five Hindu caves and a few Buddhist stupa mounds that date back to the 2nd century BCE,[4][2][5] as well as a small group of two Buddhist caves with water tanks.

    </p>
    <img class="img11 fleft" src="/eztravels/images/elephant.jpg">

    <p id="p1">Timings:-9:00AM-8:00PM</p>
    <p id="p2">Entry Fee:100/-</p>
    <a type="button" href="booking" class="btn btn-primary" id="p3">Book Now</a>
<footer style="position:absolute; bottom:0px; width:100%;">
  <?php $this->load->view("layout/footer") ?>
</footer>
</body>
