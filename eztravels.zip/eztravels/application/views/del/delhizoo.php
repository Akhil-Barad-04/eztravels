
<?php $this->load->view("layout/header") ?>
<head>
  <link rel="stylesheet" href="<?php echo base_url("assets/css/bootstrap.css") ?>">
  <style>
      body{

      }
      .fleft{
        position: absolute;
        right:20px;
        float:right;
        height:500px;
        width:50%;
        margin-top:0px;
        border-radius: 10px;
        margin-right:20px;
      }
      #fright{
        color:white;
         margin-left:50px;
         width:900px;
         float:left;

      }
      .img11{
        width:500px;
        height:400px;
      }
      #p1{
          color:white;
          position: absolute;
          bottom:250px;
          left:350px;
          font-size:30px;
      }
      #p2{
          color:white;
          position: absolute;
          bottom:200px;
          left:450px;
          font-size:20px;
      }
      #p3{

          color:white;
          position: absolute;
          bottom:150px;
          left:465px;
      }
      #hh{
        position: relative;
        margin:20px 0 20px 0;
        color:white;
        left:45%;
      }

  </style>
</head>
<body style="background-color:black; overflow:hidden;">
  <h2 id="hh">Delhi Zoo</h2>

    <p id="fright">

      The National Zoological Park (originally Delhi Zoo) is a 176-acre (71 ha) zoo in New Delhi , India. A 16th-century citadel, a sprawling green island and a motley collection of animals and birds, all in the middle of a burgeoning urban Delhi. The zoo is home to about 1350 animals representing almost 130 species of animals and birds from around the world. The zoo can be seen on foot or using a battery-operated vehicle which can be rented at the zoo.[4] Visitors are not permitted to bring any food other than drinking water, but there is a canteen in the zoo.[5] In 2014 a visitor who was mentally ill, killed as he had fallen into the white tigers enclosure.

    </p>
    <img class="img11 fleft" src="/eztravels/images/delhizoo.jpg">

    <p id="p1">Timings:-9:00AM-8:00PM</p>
    <p id="p2">Entry Fee:100/-</p>
    <a type="button" href="booking" class="btn btn-primary" id="p3">Book Now</a>
<footer style="position:absolute; bottom:0px; width:100%;">
  <?php $this->load->view("layout/footer") ?>
</footer>
</body>
