
<?php $this->load->view("layout/header") ?>
<head>
  <link rel="stylesheet" href="<?php echo base_url("assets/css/bootstrap.css") ?>">
  <style>
      body{

      }
      .fleft{
        position: absolute;
        right:20px;
        float:right;
        height:500px;
        width:50%;
        margin-top:0px;
        border-radius: 10px;
        margin-right:20px;
      }
      #fright{
        color:white;
         margin-left:50px;
         width:900px;
         float:left;

      }
      .img11{
        width:500px;
        height:400px;
      }
      #p1{
          color:white;
          position: absolute;
          bottom:250px;
          left:350px;
          font-size:30px;
      }
      #p2{
          color:white;
          position: absolute;
          bottom:200px;
          left:450px;
          font-size:20px;
      }
      #p3{

          color:white;
          position: absolute;
          bottom:150px;
          left:465px;
      }
      #hh{
        position: relative;
        margin:20px 0 20px 0;
        color:white;
        left:45%;
      }

  </style>
</head>
<body style="background-color:black; overflow:hidden;">
  <h2 id="hh">Red Fort</h2>

    <p id="fright">

      The Red Fort is a historic fort in the city of Delhi in India that served as the main residence of the Mughal Emperors. Emperor Shah Jahan commissioned construction of the Red Fort on 12 May 1638, when he decided to shift his capital from Agra to Delhi. Originally red and white, Shah Jahan's favourite colours, its design is credited to architect Ustad Ahmad Lahori, who also constructed the Taj Mahal. It was constructed between May 1639 and April 1648.

      On 15 August 1947, the first prime minister of India, Jawaharlal Nehru, raised the Indian national flag above the Lahori Gate.[1] Every year on India's Independence Day (15 August), the prime minister hoists the Indian "tricolour flag" at the fort's main gate and delivers a nationally broadcast speech from its ramparts.



    </p>
    <img class="img11 fleft" src="/eztravels/images/redfort.jpg">

    <p id="p1">Timings:-9:00AM-8:00PM</p>
    <p id="p2">Entry Fee:100/-</p>
    <a type="button" href="booking" class="btn btn-primary" id="p3">Book Now</a>
<footer style="position:absolute; bottom:0px; width:100%;">
  <?php $this->load->view("layout/footer") ?>
</footer>
</body>
