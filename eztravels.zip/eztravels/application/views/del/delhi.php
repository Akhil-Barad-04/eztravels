<?php $this->load->view("layout/header") ?>


<style>
.hello{
  background:url(golkonda.jpg);
}

#h1{
  color: black;
  text-align: center;
  margin-bottom: 20px;
  margin-top: 20px;
}
.imgp{
  color:black;
  font-size:20px;
text-align: center;
}
.imgh{
  width:500px;
  height:400px;
  display: block;
 margin-left: auto;
 margin-right: auto;
  border-radius: 10px;
}
</style>

<h1 id="h1"> DELHI</h1>
<body class="hello"style="background-color:white; ">
  <a href="redfort" ><img class="imgh" src="/eztravels/images/redfort.jpg"></a>
  <p class="imgp">Red Fort</p>
  <a href="delhizoo" ><img class="imgh" src="/eztravels/images/delhizoo.jpg"></a>
  <p class="imgp">Delhi Zoo</p>
  <a href="tajmahal" ><img class="imgh" src="/eztravels/images/tajmahal.jpg"></a>
  <p class="imgp">Taj Mahal</p>


</body>






<?php $this->load->view("layout/footer") ?>
