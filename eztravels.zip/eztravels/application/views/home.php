

<?php $this->load->view("layout/header") ?>
<head>
  <link rel="stylesheet" href="<?php echo base_url("assets/css/bootstrap.css") ?>">
</head>
<style>

/* Make the image fully responsive */
.carousel-inner img {
width: 100%;
height: 100%;
}
</style>


<body style="width:100vw;">

  <div id="demo" class="carousel slide" data-ride="carousel">
    <ul class="carousel-indicators">
      <li data-target="#demo" data-slide-to="0" class="active"></li>
      <li data-target="#demo" data-slide-to="1"></li>
      <li data-target="#demo" data-slide-to="2"></li>
    </ul>
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="<?php echo base_url('car.jpg'); ?>" alt="Los Angeles" width="1100" height="500">
        <div class="carousel-caption">
          <h3><b>EzTravels</b></h3>
          <p>We had such a great time in LA!</p>
        </div>
      </div>
      <div class="carousel-item">
        <img src="<?php echo base_url('car1.jpg'); ?>" alt="Chicago" width="1100" height="500">
        <div class="carousel-caption">
          <h3><b>EzTravels</b></h3>
          <p>Thank you, Chicago!</p>
        </div>
      </div>
      <div class="carousel-item">
        <img src="<?php echo base_url('car2.jpg'); ?>" alt="New York" width="1100" height="500">
        <div class="carousel-caption">
          <h3><b>EzTravels</b></h3>
          <p>We love the Big Apple!</p>
        </div>
      </div>
    </div>



    <a class="carousel-control-prev" href="#demo" data-slide="prev">
      <span class="carousel-control-prev-icon"></span>
    </a>
    <a class="carousel-control-next" href="#demo" data-slide="next">
      <span class="carousel-control-next-icon"></span>
    </a>
  </div>



<!--about us-->

<!--service part-->

<section>
<div class="hie">


<div class="container-field">
<div class="text-center bg-dark text-light p-2"><h1>Services We Provide</h1></div>
<div class="card bg-light mt-3 mb-3"></div>
<div class="row">

    <div class="col-lg-4 col-md-4 col-12">
    <div class="card text-center" style="width:400px">
    <img class="card-img-top" style="width:400px height:400px" src="<?php echo base_url('Hyderabad.jpg'); ?>" alt="Card image">
    <div class="card-body">
      <h4 class="card-title">Hyderabad</h4>
      <h6 class="card-text">Click the Profile to know about the services in Hyderabad</h6>
      <a href="hyd/hyderabad" class="btn btn-primary">See Profile</a>
    </div>
    </div>
  </div>

      <div class="col-lg-4 col-md-4 col-12">
  <div class="card text-center" style="width:400px">
    <img class="card-img-top a" src="<?php echo base_url('Kolkatta.jpg'); ?>" alt="Card image">
    <div class="card-body">
      <h4 class="card-title">Kolkata</h4>
      <h6 class="card-text">Click the Profile to know about the services in Kolkata</h6>
      <a href="kol/kolkata" class="btn btn-primary">See Profile</a>
    </div>
    </div>
  </div>
  <div class="col-lg-4 col-md-4 col-12">
  <div class="card text-center" style="width:400px">
    <img class="card-img-top a" src="<?php echo base_url('Mumbai.jpg'); ?>" alt="Card image">
    <div class="card-body">
      <h4 class="card-title">Mumbai</h4>
      <h6 class="card-text">Click the Profile to know about the services in Mumbai</h6>
      <a href="mumb/mumbai" class="btn btn-primary"> See Profile </a>
    </div>
    </div>
  </div>

  </div>
</div>
</section>
</body>


<div style="overflow:hidden;">
  <?php $this->load->view("layout/footer") ?>
</div>
